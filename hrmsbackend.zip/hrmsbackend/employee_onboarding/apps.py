from django.apps import AppConfig


class EmployeeOnboardingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'employee_onboarding'
